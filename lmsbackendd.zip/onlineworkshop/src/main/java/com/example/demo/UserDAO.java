package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserDAO {
	
	@Autowired
	UserInterface ui;
	
	public String insertUser(User user)
	{
		ui.save(user);
		return "user added";
	}
    
	public User findUser(String email)
	{
		return ui.findByEmail(email);
				
	}
}
