package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class UserController {
	
	@Autowired
	UserDAO udao;
	
	@GetMapping("/")
	public String home() {
		return "Home";
	}
	
	@PostMapping("/adduser")
	public String fun1(@RequestBody User user)
	{
		return udao.insertUser(user);
	}
	
	@PostMapping("/userlogin")
	public String fun2(@RequestBody User user)
	{
		User user2 = udao.findUser(user.getEmail());
		
		if((user2 != null) && (user.getPassword().equals(user2.getPassword())))
		{
			return "true"; 
		}
		return "false";
	}

   
}
