package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class User {
	String name;
	String password;
	@Id
	String email;
	String universityname;
	String joinyear;
	int no_years;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUniversityname() {
		return universityname;
	}
	public void setUniversityname(String universityname) {
		this.universityname = universityname;
	}
	public String getJoinyear() {
		return joinyear;
	}
	public void setJoinyear(String joinyear) {
		this.joinyear = joinyear;
	}
	public int getNo_years() {
		return no_years;
	}
	public void setNo_years(int no_years) {
		this.no_years = no_years;
	}
	@Override
	public String toString() {
		return "User [name=" + name + ", password=" + password + ", email=" + email + ", universityname="
				+ universityname + ", joinyear=" + joinyear + ", no_years=" + no_years + "]";
	}
	
	

}
